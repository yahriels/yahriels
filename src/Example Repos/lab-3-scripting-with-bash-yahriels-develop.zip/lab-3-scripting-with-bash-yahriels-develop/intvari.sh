#!/bin/bash

# Variance of a sample set is:
# Sum of the squares of the difference from the mean, divided by the number of samples
# Sum( x_i - mu )^2 / N

echo "Integer Variance Calculator"

if [ $# -lt 2] # Add check for 2 or more arguments
then
    echo "Not enough samples brosef!"
    exit
else
    echo "I recieved $# samples."
fi

mean=0
for sampval in "$@"
do
    ((sum+= $sampval))
done

((mean= $sum / $#))

echo "The integer mean value is: $mean"

vari=0
# Now compute the variance

for sampval in "$@"
do
    ((sum2+=($sampval - $mean)**2))
done

((vari=$sum2 / $#))

echo "The integer standard deviation is: $vari"
