double ext_func(double x) {
    return x * x;
}