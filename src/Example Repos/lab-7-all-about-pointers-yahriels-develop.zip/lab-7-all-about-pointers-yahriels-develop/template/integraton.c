// Declare your functions here

// Use the names exactly as spelled in the sample main.c file
// Error to do so means your program won't get called

// Argument order is:
//      Integrand Function
//      Lower Bound
//      Upper Bound
//      Order (Gauss only - Integer)
