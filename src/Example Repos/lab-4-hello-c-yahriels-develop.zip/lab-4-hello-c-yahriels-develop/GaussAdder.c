#include<stdio.h>
#include<stdlib.h>

int i;
int sum;
int GaussAdder(){
  float begin;
  printf("Enter an integer please:");
  scanf("%f", &begin);
  int n = (int)begin;

  if (begin != n)
    {
      printf("Sorry that is not an integer\n");
    }
  else
    {
      printf("I will now start adding numbers from 1 to n. \n");
      for (i == 1; i < n + 1; i = i + 1 ) {
	sum = (i*(i+1))/2;
      }
    }
  printf("Result %d\n", sum);
  return 0;
}

int main(void){
  int n;
  printf("%d \n", n);
  GaussAdder();
  printf("This is your value using Gaussian Method from 1 to %d\n", n);
  return 0;
}
