#include<stdio.h>

int main()
{
  float begin;

  printf("Hello! Please give me an integer: ");
  scanf("%f", &begin);
  int b = (int)begin;

    if (begin != b)
      {
	printf("Sorry that is not an integer\n");
      }
    else
      {
	int i=1;
	float second;
	while (i<6)
	  {
	    printf("Thanks! Please give me another integer: ");
	    scanf("%f", &second);
	    if (second != (int)second)
	      {
		printf("This is not an integer\n");
		break;
	      }
	    i++;
	    if (i==5)
	      {
		printf("Thanks! i am happy with five integers. \n");
		break;
	      }
	  }
      }
  return 0;
}
