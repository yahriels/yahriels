/* Yahriel Salinas-Reyes
1st C file
Needs to call in function to print: "Hello World*/
#include<stdio.h>

int test () {
  printf("Hello, World!\n");
}

int main(void){

  test(); /*end program line*/
} /*end of program file*/
