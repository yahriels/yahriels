#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>

int main() {

  int n;

  printf("Hello! How many chars should I take? \n");
  scanf("%d", &n);


  while (getchar() != '\n');
  int i;
  char in[n];

  for (i = 1; i <= n; i = i + 1) {
      if (i ==1) {
	printf("Please give me a char: ");
	scanf("%s", &in[i]);

	while (getchar() != '\n');

	if (isalpha(in[i]) ==0 || strlen(&in[i]) > 1) {
	  printf("Sorry, that is not a char. \n");
	  break;
	}
      }
      else {
	printf("Thanks! Please give me another char: ");
	scanf("%s", &in[i]);

	while (getchar() != '\n');

	if (isalpha(in[i]) ==0 || strlen(&in[i]) > 1) {
	    printf("Sorry, that is not a char. \n");
	    break;
	  }
      }
      if (i == n){
	printf("Thanks! I am happy with %d chars. \n", n);
      }
  }
}

	  
