#include<stdio.h>

int main()
{
  float runtime;

  printf("Enter a runtime: ");
  scanf("%f", &runtime);

  if (runtime == (int)runtime)
    {
      printf("That is an integer\n");
    }
  else
    {
      printf("That is not an integer\n");
    }
  return 0;
}
