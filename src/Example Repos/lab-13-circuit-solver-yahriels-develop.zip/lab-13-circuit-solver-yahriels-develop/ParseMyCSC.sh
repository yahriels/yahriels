#!/bin/bash

FILE=$1 # Take input of File

MaxN=0

IFS=$'\n' #INTERNAL FIELD SEPARATOR, spliting on lines
ARRAY_OF_LOOPS=(`grep L $1`)
#echo "Got ${ARRAY_OF_LOOPS[0]} ${ARRAY_OF_LOOPS[1]}" #Test

for (( i = 0; i < ${#ARRAY_OF_LOOPS[@]}; i++ ))
do
    LINE="${ARRAY_OF_LOOPS[$i]}"

    if   [[ "$LINE" =~ [L],([0-9,\s]+) ]] #Rematch dis bitch with MEM
	#NOTE: Don't konw how many nodes yet
    then
#	echo "HERE I guess we got a lopp ${BASH_REMATCH[1]}"
	IFS=',' read -ra NODES <<< "${BASH_REMATCH[1]}"
#		echo "NODES[0] is ${NODES[0]}"
	ARRAY_OF_LOOPS[$i]="" #THIS MEANS EMPTY OUT ARRAY
	for (( j = 1; j < ${#NODES[@]}; j++ ))
	do
	    ARRAY_OF_LOOPS[$i]+="    ${NODES[(($j-1))]},${NODES[$j]}"
	done
	ARRAY_OF_LOOPS[$i]+="    ${NODES[-1]},${NODES[0]}"
        
    else
	#DEFAULT FOR IF CODE BREAKS UP WITH UR MOM
	echo "Ope, guess I borke up with ur mom"

    fi
    


done



while read LINE
do

    #Program will run as along as there is info to sparse
    case $LINE in

	[VR],[0-9]*,[0-9]*,[0-9]* )
	    [[ "$LINE" =~ ([VR]),([0-9]*),([0-9]*),([0-9]*) ]] # Rematch w/ MEM
	    #echo "here is thE lINE wE WaNT to MAtCh with: $LINE"

	    if [ "${BASH_REMATCH[1]}" = R ]
	    then # Poopoolae the Equation into EQN[]
		EQN["${BASH_REMATCH[2]}"]+="-1 i_${BASH_REMATCH[2]}${BASH_REMATCH[3]}     " #Negative Direc
		EQN["${BASH_REMATCH[3]}"]+=" 1 i_${BASH_REMATCH[2]}${BASH_REMATCH[3]}     " #Positive Direc
	    fi


#echo "Before loop: ${ARRAY_OF_LOOPS}"
	    #POPLATE VOLTAGE Eqn's
	    ## SOLVE, find and replace loop place holders
	    for (( i = 0; i < ${#ARRAY_OF_LOOPS[@]}; i++ ))
	    do
		
		LINE="${ARRAY_OF_LOOPS[$i]}"
	        #echo "BRo df is happening"
		#A=`echo \$LINE | sed  s/3/!!!/`
		#echo "HERE: $A"
		
		A=`echo \$LINE | sed s/${BASH_REMATCH[2]},${BASH_REMATCH[3]}/${BASH_REMATCH[4]}i_${BASH_REMATCH[2]}${BASH_REMATCH[3]}/`
		B=`echo \$A | sed s/${BASH_REMATCH[3]},${BASH_REMATCH[2]}/-${BASH_REMATCH[4]}i_${BASH_REMATCH[2]}${BASH_REMATCH[3]}/`
		ARRAY_OF_LOOPS[$i]="$B"
		#echo "A is ${A}"
		#echo "B is ${B}"
		#ARRAY_OF_LOOPS[$i]=

	    done
	    

	    #SET Max Node N
	    if [ ${BASH_REMATCH[2]}  -gt $MaxN ]
	    then
		MaxN=${BASH_REMATCH[2]}
	    fi
	    if [ ${BASH_REMATCH[3]}  -gt $MaxN ]
	    then
		MaxN=${BASH_REMATCH[3]}
	    fi
	    ;;
	
	[L],[,0-9\s]* )
	    [[ "$LINE" =~ [L],([0-9,\s]+) ]] #Rematch dis bitch with MEM
#	    echo "Bruh we got loop:  ${BASH_REMATCH[1]}"
	    ;;
	
	"#"*) #Check for comments
	    
	    ;;

	*) #DEFAULT PRINT ERRROR MESSAGE
	    echo "Couldn't Parse this line $LINE";
	    echo "Bitch we expectin' something line integers"
	    ;;
	esac

done < $FILE


for EQUATION in $(seq 1 $MaxN)
do
    echo "${EQN[$EQUATION]}" 
done

echo "${ARRAY_OF_LOOPS[*]}"

