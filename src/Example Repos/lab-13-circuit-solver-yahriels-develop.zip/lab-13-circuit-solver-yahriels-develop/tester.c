#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include "gsl/gsl_linalg.h"






int main (int argc, char *argv[])
{
  FILE * pfile;
  pfile = fopen(argv[1], "r");
  if(pfile == NULL)
    {
      printf("File did not open properly or does not exist bruh");
      return 1;
    }



  char command[50];
  char test[50];


  
  strcpy(test,argv[1]);
  strcpy(command,"./ParseMyCSC.sh ");

  strcat(command,test);
  strcat(command,"> ans.csv");
  system(command);
   printf("\nSo far so good\n");

  FILE * tempfile;
  tempfile = fopen("ans.csv","r+");
  if(tempfile == NULL)
    {
      printf("File did not open properly or does not exist bruch");
      return 1;
    }
  

  printf("'ParseMyCSC.sh' shell file has sparsed file: 'test.csv' within this c file\n Answers have been written out to file named 'ans.csv'\n See ya later AERE 361 \n \n");
  
}
