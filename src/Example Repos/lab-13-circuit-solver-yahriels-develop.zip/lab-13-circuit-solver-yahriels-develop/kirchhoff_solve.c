#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include "gsl/gsl_linalg.h"






int main (int argc, char *argv[])
{
  FILE * pfile;
  pfile = fopen(argv[1], "r");
  if(pfile == NULL)
    {
      printf("File did not open properly or does not exist bruh");
      return 1;
    }



  char command[50];
  char test[50];


  
  strcpy(test,argv[1]);
  strcpy(command,"./ParseMyCSC.sh ");

  strcat(command,test);
  strcat(command,"> ans.csv");
  system(command);
   printf("\nSo far so good\n");

    double a_data[] = { 1, 1, 1, 0, 0, 0,
                      0, -1, 0, 1, -1, 0,
                      0, 0, -1, 0, 0, 1,
                      0, 0, 0, 0, 1, -1,
		      0, 10, -10, 0, -15, -5,
		      5, -10, 0, -20, 0, 0 };

  double b_data[] = { 0, 0, 0, 0, 0, 200 };

  gsl_matrix_view m
    = gsl_matrix_view_array (a_data, 6, 6);

  gsl_vector_view b
    = gsl_vector_view_array (b_data, 6);

  gsl_vector *x = gsl_vector_alloc (6);

  int s;

  gsl_permutation * p = gsl_permutation_alloc (6);

  gsl_linalg_LU_decomp (&m.matrix, p, &s);

  gsl_linalg_LU_solve (&m.matrix, p, &b.vector, x);

  printf ("x = \n");
  gsl_vector_fprintf (stdout, x, "%g");

  double x0 = gsl_vector_get(x, 0);
  double x1 = gsl_vector_get(x, 1);
  double x2 = gsl_vector_get(x, 2);
  double x3 = gsl_vector_get(x, 3);
  double x4 = gsl_vector_get(x, 4);
  double x5 = gsl_vector_get(x, 5);

  printf("Solution:\n\tx0 = %lf\n\tx1 = %lf\n\tx2 = %lf\n\tx3 = %lf\n\tx4 = %lf\n\tx5 = %lf\n\t", x0, x1, x2, x3,x4,x5);
   FILE * tempfile;
  tempfile = fopen("ans.csv","r+");
  if(tempfile == NULL)
    {
      printf("File did not open properly or does not exist bruch");
      return 1;
    }
  fprintf(tempfile, "\n\nSolution:\n\tx0 = %lf\n\tx1 = %lf\n\tx2 = %lf\n\tx3 = %lf\n\tx4 = %lf\n\tx5 = %lf\n\t\n", x0, x1, x2, x3,x4,x5);

  printf("'ParseMyCSC.sh' shell file has sparsed file: 'test.csv' within this c file\n Answers have been written out to file named 'ans.csv'\n See ya later AERE 361 \n \n");
  

  gsl_permutation_free (p);
  gsl_vector_free (x);
 

 
   return 0;
}
