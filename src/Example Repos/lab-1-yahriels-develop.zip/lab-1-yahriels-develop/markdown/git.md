# Discussion of Git Workflow and Importance of Good Documentation
## **Git Workflow**
The git workflow at first was a bit of a foreign concept to me, in comparison to some other languages like MatLab, Python, and C+. After a bit more reflection, the workflow and commands are becoming more familiar and seem to be more universial in comparison to some of those other langauages I've used before. In this section I will be providing my understanding of the Git Workflow thus far.

### It started to _click with me_ when I became acquianted with shell commands:
As far as I understand, shell commands are near the top of the heiarchy of the **Git Workflow**. 
- `cd`
- `cd <specific directory location>`
- `mkdir <specific file>`
- `rmdir <specific file>`
As these functions seem to be abbreviations for commands like _change directory_, _change to specific directory_, _make directory_, and  _remove directory_, it makes it pretty simple to remember and navigate through directories.

**These shell functions I observed also tend to be multifunctional:**
As `cd` command elevates you to the higher directory, it can also take you to an intended directory when a specific directory is written directly after the command.
**They are also inverses of each other:**
Just as the `mkdir` command _makes a directory_, the `rmdir` command _removes a directory_. Pretty neat how this syntax related to mathematical concepts in that way which makes it easier to remember and understand.

### Git Basic Commands
Once I knew how to use shell commands, I understood git basic commands as a step directly below shell commands in the heiarchy of the **Git Workflow**:
Some Git Basic Commands Include:
- `git status`
- `pwd`
- `less`
- `ls`
- `git checkout`
- `git add`
- `git commit`
- `git branch`

I understand theses commands as supplemental tools to shell commands which offer the user:
- Awareness of their workspace while navigating directories
- Ability to enter and select specific work environments
- Ability to track work environments, or items within work environments
- Ability to store or save changes
- Ability to create new work environments as brances

_Other commands I learned in this lab seem to operate in different, typically lower,  levels of the **Git Workflow** to do specific tasks within a work environment. Like alter a text file, leave foot notes during work processes, optimize the **Git Workflow** in various ways to simplify a system, or upload changes to your global github repository._


## Importance of Good Documentation
In this section, I will be discussing the importance of good documentation and how the **Git Workflow** plays a role in this subject.

### Good Documentation as a whole
Good documentation is very important in all areas of STEM, English, and any other areas of profession which utilize documentation. Documentation can play many roles in any area, but for this discussion, we will utilize the research and STEM professions as the focus. Right off the bat, some obvious reasons why good documentation is important include:

1. Documentation and explanation of research, scientific, mathematic, etc. processes.
2. Use of jargon, specific language, and terms that are subject specific within a given profession. **Especially since some words have different meanings across different professions and subject areas**
3. Use of subject and profession specific formatting. Different areas prioritize different informational items which changes formatting across some areas.
4. Credibility, which is very important since you need to reference and credit work that isn't yours as well as distinguish what you are contributing to the documentation. **Or else you can get sued for copyright!**
5. Ease of readability, we must provide information in a way that it is easy to understand so that we can enter constructive conversations about what we are documenting.

### The Role of **Git Workflow**

Reffering to the items above, the **Git WorkFlow** assists the user with many capabilities to meet these conditions.
Some of the ways the **Git Workflow** does this includes:
1. Through text files and other commands, Git provides an writing environment and other capaibilities for documenting in a universal writing format, that can then be converted to practically any other writing format or environment. This is very useful in documenting processes and ensuring that it may be used for longer periods of time, until the content is updated.
   - `git commit -m "Description of action"` This function is an example of a  useful command in documenting notes and descriptions of changes and processes completed.
2. Since git is a universal writing format, you only need to worry about getting the correct content down.
3. Git can automatically convert what you have written, and adjust it to any format so you don't have to worry about it!
4. With commands and no need for adjusting formatting, you only need to worry about getting the right info once again! You don't have to navigate through formatting for references or bibliographies.
5. With the syntax the user utilizes, Git ensures that your documentation is presented in the best way possible for ease of readability.

## Overall, through this lab I have reflected on how important good documentation is. I have also learned how **Git Workflow** offers many features to make our lives easier in documenting overall allowing us to conserve energy and time!
