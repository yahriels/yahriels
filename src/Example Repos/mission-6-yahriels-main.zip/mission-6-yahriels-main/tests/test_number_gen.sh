#/bin/bash
# AerE 361 Mission 6
# Fall 2022
# Professor Nelson
# Number_Gen Test Script
# DO NOT EDIT THIS SCRIPT
export TERM=xterm-256color
FILE_SRC="number_gen.c"
FILE_EXE="number_gen.out"
FILE_TEST="test_file.txt"
tput setaf 6
echo "Starting tests..."
echo

#Run our programs and store the results

# Test 1
one_ex_test=$(./$FILE_EXE $FILE_TEST)
one_ex_test_status=$?

if [ ${one_ex_test_status} -eq 0 ]
then
  tput setaf 2
  echo "Running Program Test 1 ....OK"
else
  tput setaf 1
  echo "Running Program Test 1 ....FAILED"
  tput setaf 7
  echo "Program 1 failed to run, cleaning up files."
  rm  $FILE_EXE $FILE_TEST >/dev/null
  exit 1
fi

if [ -s $FILE_SRC ];
	then
  	echo -e "Checking that $FILE_SRC is not empty....OK"
		if [ -s $FILE2 ];
			then
			echo -e "Checking that $FILE_TEST is not empty...OK"
    	if grep -q "10" $FILE_TEST && grep -q "50" $FILE_TEST && grep -q "90" $FILE_TEST;
    		then
      		echo -e "Validating values stored in $FILE_TEST....OK"
    		else
      	echo -e "Validating values stored in $FILE_TEST....FAILED"
      	exit 1
			fi
		else
			echo -e "Checking that $FILE_TEST is not empty....FAILED"
			exit 1
		fi
else
    echo -e "Checking that $FILE_TEST is not empty....FAILED"
    exit 1
fi

echo
tput setaf 7
echo "All tests passed, cleaning up files."
rm  $FILE_EXE $FILE_TEST >/dev/null
exit 0
