#include <stdio.h>
#define maxline 80

int main(void)
{
  char fname[80];

  FILE * pfile;
  int return_error = -1;

  printf("Enter a file name: ");
  scanf("%s", fname);
  pfile = fopen(fname, "r");
  if (pfile == NULL)
    {
      printf("Error opening file, ending with return %d\n", return_error);
      return return_error;
    }

  int count=0;
  char c;
  
  for (c = getc(pfile); c != EOF; c = getc(pfile))
    {
      if (c == '\n')
	{
	  count += 1;
	}
    }
  char line[maxline];
  int i;
  int t = count -3;

  rewind(pfile);

  for (i=1; i<=count; i++)
    {
      fgets(line, maxline, pfile);
      if (i>t)
	{
	  printf("%s", line);
	}
    }
  fclose(pfile);
  return 0;
}
