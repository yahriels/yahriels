#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <math.h>
/*#include <libm.a>*/


int inputcheck()
{

}

int make()
{
  float arrsize;
  printf("Please give me an array size: ");
  scanf("%f", &arrsize);
  int b = arrsize;
  printf("Array size: %d\n", b);

  if (arrsize != b || arrsize <1 || arrsize > 250)
    {
      printf("This is not a valid array size\n");
      return 2;
    }
  float arr[b];
  float * array;
  float check;
  int i;

  array = (float*) malloc(arrsize * sizeof((int)arrsize));

  for(i=0; i<= arrsize; i++)
    {
      arr[i] = 1 + pow(i,2) + pow(1,3)/3;
    }

  while(getchar() != '\n');
  printf("What element number are we finna retrieve bruh? \n");
  scanf("%f", &check);
  int c = check;
      printf("Input: %d\n", c);
      printf("Array size: %d\n", b);
  if(check != c || check > b || check <1)
    {

      printf("Bruh this input ain't valid gucci mane\n");
      return 1;
    }
  else
    {
      float output;
      output = arr[c-1];
      printf("This element is equal to %f, all is good in the world broski\n", output);
    }
  free(array);
  return 0;

  
}


    
int fcheck()
{
  int b;
  float arrsize;
  float arr[b];
  float * array;
  float check;
  int i;
  int c = check;

  if(check != c || check > arrsize || check <1)
    {
      printf("Bruh this input ain't valid gucci mane\n");
      return 1;
    }
  else
    {
      float output;
      output = arr[c-1];
      printf("This element is equal to %f, all is good in the world broski\n", output);
    }
  free(array);
  return 0;
}


int main(void)
{
  
   make();
}
