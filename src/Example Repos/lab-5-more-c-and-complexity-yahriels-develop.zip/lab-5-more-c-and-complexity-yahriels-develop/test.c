#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (void) {
char str [80]; /*str is an 80-character string*/
float f; /*f is our example floating-point number*/
FILE * pFile; /*pFile is the file stream where we will write out*/
int return_error = -1; /*this is the indicator of a NULL pointer*/
pFile = fopen ("myfile.txt","w+"); /*open the file with read&write permission*/
if (pFile == NULL) { /*always check for errors before accessing the file*/
fprintf(stderr, "ERROR opening OUT file; Ending with return %d\n", return_error);
return return_error; /*indicate an eerror and end execution */
} /*end if*/
 fprintf (pFile, "%f %s", 3.1416, "PI"); /*writes float number and string to "myfile.txt"*/
rewind (pFile); /*rewinds and sets the FILE pointer to the beginning, to now be read*/
 fscanf (pFile, "%f", &f); /*reads float number in file*/
 fscanf (pFile, "%s", str); /*reads string in file*/
 fclose (pFile); /*closes file */
 printf ("I have read: %f and %s \n",f,str); /*prints results*/
return 0; /*terminate normally*/
} /*end main*/
