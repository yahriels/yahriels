#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

int fiLE() {
  char s[100];

  printf("Enter a filename: \n");
  scanf("%s", s);
  printf("Your input is: %s\n", s);
  float f; /*f is our example floating-point number*/
  FILE * pFile; /*pFile is the file stream where we will write out*/
  int return_error = -1; /*this is the indicator of a NULL pointer*/
   /*open the file with read&write permission*/

} /*end if*/




int newfiLE(){  /*For writing into file, rewinding, reading, closing file, and printing first 3 lines*/
  FILE * pFile;
  char s[100];
  int n;
  int *foo; /*pointer*/
  int i;
  int fail;
  if (fail = 1)
    {
  printf("How many numbers are we writing? Type 0 if file already exists: \n");
  scanf("%d", &n);
  foo = malloc(sizeof(int) * n);
  
  printf("Writing 100 numbers to array");
   for (i=0; i<n; ++i){
     i + 1 == foo[i];
 }

  
 printf("Writing 100 number to file:  %s", s);
  for (i=0; i<100; ++i){
   fprintf (pFile, "%d\n", i+1);
 }
  

 rewind (pFile);
 printf("Rewinding to read file");

 for (i=0; i<n; ++i){
   fscanf (pFile, "%d\n", &foo[i]);
    printf("Output: %d\n", foo[i]);
  
 }

 fclose (pFile);
 printf("File %s is now closed\n", s);

 if (i==n){
   printf ("I have read: %d numbers from %s\n", i, s);
  
 }
 free(foo);
    }
  else
    {
      printf("Ending Program now");
    }
}

int check(){
     char s[100];  
   FILE * pFile;
   printf("Checking if file %s exists.\n", s);
   pFile = fopen (s, "r");
   int fail;
   if (pFile != NULL)
    {
     
       fprintf(stderr, "Error, file already exists!; Ending with return %d\n", -1);
      fclose(pFile);
      printf("Your input file is %s is closed. \n", s);
      return -1;
      fail = -1;
    }
   else
    {
      printf("File doesn't exist, Let's make a new one\n");
      pFile = fopen(s, "w+");
      printf("Your new file is: %s\n", s);
      fail = 1;
    }
}

   
 
int main(void)
{
  fiLE() < check() < newfiLE();

 
    return 0;
}
