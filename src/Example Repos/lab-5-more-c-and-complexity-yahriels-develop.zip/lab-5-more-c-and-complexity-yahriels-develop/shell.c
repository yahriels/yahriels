#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <math.h>

/*Write a function to PRINT an NXN test matrix*/

/* Needed for debugging and can be used for final output */
void print_matrix(int N, int number_width, int myMatrix [N] [number_width]) {

int m,n; /*loop counters: row, column*/

for (m= 0; m < N; m++) {

for (n = 0; n < N; n++) {

printf ("%*d", number_width, myMatrix[m][n]); /*printf ("%d%d ", number_width, m,n) ;*/

} /*end for n*/
 printf("\n");
} /*end for m*/
 printf("\n");

return; /* return normally*/
} /*end print_matrix */


int main (void) {

  /*1. Accept and validate input*/

float arrsize;

printf("Please give me an array size\n");

scanf("%f", &arrsize);

int b = arrsize;

if(arrsize != b | arrsize <1 || arrsize > 100)
  {
  
printf("This is not a valid array size\n");
return 2;

}



int number_width = b;

int arr[b][b];
/* 2. Allocate the array 
		  Using: code from Section 5.3.2 lab manual*/

int **bar; /* double pointer */

bar = malloc(sizeof(int *) * b); /*first allocate the array of int * */
 for(int i = 0 ; i <b ; ++i) { /*loop through this array of int * */
   bar[i] = malloc(sizeof(int)*b); /*allocate a column of ints each time */
 } /*end for*/

 
/* 3. Fill the array */
int narr[b][number_width];

int x = floor(b/2)-1;

int y = floor(b/2)-1;

int x2 = abs(x);

int y2 = abs(y);

int k,j,a;

int s = 0;

int c = 1;

int d = 0;

if (b%2 != 0)

{
  x = ceil(b/2);
  y = ceil(b/2);
  x2 = abs(x);
  y2 = abs(y);
 }
 
for (k=1; k<= (b-1); k++) {
  for(j = 0; j<(k<(b-1)?2:3); j++) {
    for(a= 0; a<=s; a++) {
      narr[x2][y2] = c;
      c++;
      switch (d)
	{

case 0: y2 = y2+1; break; 
case 1: x2 = x2+1; break;
case 2: y2 = y2-1; break; 
case 3: x2 = x2-1; break;
	}
    }
    d = (d+1)%4;
  }

s = s+1;
 }
 
narr[x2][y2] = c;

/*first learn to test if I'm doing this right*/
 print_matrix(b, number_width, narr);
 free(bar);

/*NOTE: the floor() in the lab algorithm should be a ceiling() !!! */

/*4. Output the array*/ /* First, to the screen, then to a file*/

char fname[7] = "ans.out";

FILE * pfile;

int r;
int h;

struct stat buffer;
int exist = stat(fname, &buffer);
 pfile = fopen(fname, "w");
 for (r = 0; r <b; r++)
   {
     for (h= 0; h <b; h++)
       {
	 fprintf(pfile, "%d\t", narr[r][h]);
       }
     fprintf(pfile, "\n");
   }

fclose(pfile);

return 0; /*exit normally if I got here( */
 }
/*end*/      
