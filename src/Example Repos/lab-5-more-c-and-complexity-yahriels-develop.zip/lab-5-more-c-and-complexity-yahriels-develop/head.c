#include <stdio.h>
#define maxline 80

int main(void)
{
  char fname[80];

  FILE * pfile;
  int return_error = -1;

  printf("Enter a file name: ");
  scanf("%s", fname);
  pfile = fopen(fname, "r");
  if (pfile == NULL)
    {
      printf("Error opening file, ending with return %d\n", return_error);
      return return_error;
    }
  char line[maxline];
  int max=0;
  while(fgets(line, maxline, pfile) != NULL && max++ <3)
    {
      printf("%s", line);
    }
  return 0;
}
