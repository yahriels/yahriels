#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

double factorial (int n)
{
  double r = 1;
  while(n>0)
    {
      r *= n; n--;
    }
  return r;
}

double e(double x, double err)
{
int n = 0;
double sum = 0;
double y = 0;
double past = -1;
 while((sum-past)>err)
   {
     past = sum;
     y = (pow(x,n))/factorial (n);
     sum+=y;
     n++;
   }
 printf("After %d ",n);
 return sum;
}

int main()

{
double x;
double err;
char c;

printf("Enter the value x for e^x: ");

if (scanf("%lf%c", &x, &c) != 2 || c != '\n')
  {
    printf("That is not an integer \n");
    return -1;
  }
 else
   {
   printf("valid integer input\n");
   }

printf("Enter the error: ");

if(scanf("%lf%c", &err, &c) != 2 || c != '\n')
  {
    printf("That is not an integer \n");
    return -1;
  }
 else
   {
  printf("valid integer input\n");
   }

double answer = e(x,err);
 printf("terms in the series, exp(%lf) is approx. %lf with an error of %lf\n",x, answer,err);

return 0;
}
