void sample_func(void) {
  printf("Hello World!");
}
