#include<stdio.h>
void sample_func();
