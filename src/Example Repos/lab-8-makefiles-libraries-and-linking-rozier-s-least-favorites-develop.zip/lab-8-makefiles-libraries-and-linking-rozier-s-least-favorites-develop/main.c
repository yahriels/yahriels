#include "module.h"
int main(void) {
  sample_func();
  return 0;
}
